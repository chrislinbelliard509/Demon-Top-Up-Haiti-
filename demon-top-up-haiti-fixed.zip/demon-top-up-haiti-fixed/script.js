let cart = [];

const translations = {
  ht:{home:'Akèy',games:'Jwèt',subs:'Abònman',cards:'Kat kado',wallet:'Wallet / Pòtfèy',orders:'Kòmand mwen yo',profile:'Pwofil',support:'Sipò'},
  fr:{home:'Accueil',games:'Jeux',subs:'Abonnements',cards:'Cartes cadeaux',wallet:'Portefeuille',orders:'Mes commandes',profile:'Profil',support:'Support'},
  en:{home:'Home',games:'Games',subs:'Subscriptions',cards:'Gift cards',wallet:'Wallet',orders:'My orders',profile:'Profile',support:'Support'},
  es:{home:'Inicio',games:'Juegos',subs:'Suscripciones',cards:'Tarjetas regalo',wallet:'Billetera',orders:'Mis pedidos',profile:'Perfil',support:'Soporte'}
};

function addToCart(id, name, price) {
  const existing = cart.find(x => x.id === id);
  if (existing) existing.qty += 1;
  else cart.push({id, name, price, qty:1});
  renderCart();
  document.querySelector('#checkout').scrollIntoView({behavior:'smooth'});
}

function changeQty(index, delta) {
  if (!cart[index]) return;
  cart[index].qty += delta;
  if (cart[index].qty <= 0) cart.splice(index, 1);
  renderCart();
}

function totalAmount() {
  return cart.reduce((sum, x) => sum + x.price * x.qty, 0);
}

function renderCart() {
  const list = document.querySelector('#cartList');
  if (!cart.length) {
    list.innerHTML = '<p class="muted">Panier ou vid. Ajoute yon pwodwi pou kontinye.</p>';
  } else {
    list.innerHTML = cart.map((x,i) => `
      <div class="cart-item">
        <span>${escapeHtml(x.name)} × ${x.qty}</span>
        <span>
          <button type="button" onclick="changeQty(${i},-1)">−</button>
          <button type="button" onclick="changeQty(${i},1)">＋</button>
          <b>$${(x.price*x.qty).toFixed(2)}</b>
        </span>
      </div>
    `).join('');
  }
  document.querySelector('#total').innerHTML = `Total <b>$${totalAmount().toFixed(2)} USD</b>`;
  const badge = document.querySelector('.icon-btn i');
  if (badge) badge.textContent = cart.reduce((n,x)=>n+x.qty,0);
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, ch => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'
  }[ch]));
}

async function checkout() {
  if (!cart.length) {
    alert('Ajoute yon pwodwi anvan ou peye.');
    return;
  }

  const paymentMethod = document.querySelector('input[name="pay"]:checked')?.value;
  const customerName = document.querySelector('#customerName')?.value.trim() || '';
  const customerPhone = document.querySelector('#customerPhone')?.value.trim() || '';
  const playerId = document.querySelector('#playerId')?.value.trim() || '';

  if (!customerName || !customerPhone) {
    alert('Tanpri mete non ou ak nimewo telefòn ou anvan ou kontinye.');
    return;
  }

  const button = document.querySelector('.pay');
  const oldText = button.textContent;
  button.disabled = true;
  button.textContent = '⏳ Ap prepare peman...';

  try {
    const orderResponse = await fetch('/api/orders', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({
        items: cart.map(x=>({id:x.id, qty:x.qty})),
        paymentMethod,
        playerId,
        customer:{name:customerName, phone:customerPhone}
      })
    });

    const orderData = await orderResponse.json();
    if (!orderResponse.ok) throw new Error(orderData.error || 'Kòmand lan pa kreye.');

    const paymentResponse = await fetch('/api/payments/create', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({orderId:orderData.order.id})
    });

    const paymentData = await paymentResponse.json();
    if (!paymentResponse.ok) {
      throw new Error(paymentData.error || 'Peman an pa disponib ankò.');
    }

    if (paymentData.checkout_url) {
      window.location.href = paymentData.checkout_url;
    } else {
      alert(`Kòmand ${orderData.order.id} kreye. Men checkout peman an pa retounen yon URL.`);
    }
  } catch (error) {
    alert(error.message);
  } finally {
    button.disabled = false;
    button.textContent = oldText;
  }
}

document.addEventListener('DOMContentLoaded', () => {
  document.querySelector('#language')?.addEventListener('change', e => {
    const t = translations[e.target.value] || translations.ht;
    document.querySelectorAll('[data-i18n]').forEach(el => {
      el.textContent = t[el.dataset.i18n] || el.textContent;
    });
  });
  renderCart();
});
