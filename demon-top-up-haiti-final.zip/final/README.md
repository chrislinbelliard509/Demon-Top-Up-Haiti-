# Demon Top Up Haiti — site final

Sit la gen yon interface dark/neon ki adapte ak mobil ak òdinatè, ak:
- Akèy / hero Demon Top Up Haiti
- Jwèt: Free Fire, PUBG Mobile, Blood Strike, Mobile Legends
- Abònman: Netflix, Disney+, Spotify, YouTube Premium
- Kat kado: Google Play, Apple Gift Card, Amazon
- Panier ak kantite pwodwi
- Checkout ak non, WhatsApp, Player ID/UID ak imèl
- NatCash, MonCash ak Visa kòm metòd peman
- Kreyasyon kòmand sou backend + istwa kòmand lokal
- Endpoint `/api/health` pou Render
- Multi-lang selector (Kreyòl, Français, English, Español)
- Responsive mobile navigation

## Lanse lokalman
```bash
npm install
npm start
```
Apre sa ouvri `http://localhost:3000`.

## Render
Gade `README_DEPLOY.txt` pou etap deploy ak environment variables.

## Sa ki rete pou LIVE
Kod sit la pare, men peman reyèl ak livrezon otomatik pa ka aktive san kont/kle sèvis yo. Mete kle gateway a sèlman nan Render Environment Variables, pa nan frontend lan.

NatCash/MonCash sèvi ak hosted checkout atravè Kobara lè merchant/API la aktive. Visa bezwen yon PSP/acquirer ki aksepte kat; Visa pou kont li pa yon payment gateway.
