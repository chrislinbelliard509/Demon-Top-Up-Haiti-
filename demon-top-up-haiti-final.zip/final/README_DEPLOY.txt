DEMON TOP UP HAITI — DEPLOYMENT

1) Upload the contents of this folder to GitHub.
2) On Render, create a Web Service from the repository.
3) Build Command: npm install
4) Start Command: npm start
5) Health Check Path: /api/health
6) Required environment variables:
   NODE_ENV=production
   PUBLIC_URL=https://YOUR-RENDER-DOMAIN.onrender.com
   ADMIN_TOKEN=CREATE-A-LONG-RANDOM-SECRET
   KOBARA_KEY=YOUR-LIVE-KOBARA-KEY
   VISA_CHECKOUT_URL=YOUR-CARD-PSP-CHECKOUT-URL
7) Configure your payment provider webhook to:
   https://YOUR-RENDER-DOMAIN.onrender.com/api/webhooks/kobara

IMPORTANT
- Do not put payment keys in frontend files.
- NatCash/MonCash checkout requires a live provider/merchant credential.
- Visa requires a card-acquiring/PSP account; Visa itself is not a merchant gateway.
- Test in sandbox before taking live payments.
